Yadukul Dairy — Node + Express + MongoDB Backend
===============================================

This scaffold provides a production-ready starting point for the backend API for Yadukul Dairy.

Features:
- Authentication (register/login) with JWT
- Role-based access: owner, staff, customer
- Products CRUD (protected)
- Orders creation, list, mark delivered
- Staff management (owner can add staff)
- Conversion logging and inventory summary
- Seed script to create owner and sample products

Quick start (local)
-------------------
1. Install dependencies:
   npm install

2. Create .env file (copy .env.example) and set MONGO_URI, JWT_SECRET
   For quick testing, you can run local MongoDB or use MongoDB Atlas.

3. Seed sample data:
   npm run seed

4. Start server:
   npm run dev
   Server runs on http://localhost:5000

API endpoints (summary)
-----------------------
- POST /api/auth/register
- POST /api/auth/login
- GET /api/products
- POST /api/products  (owner/staff)
- PUT /api/products/:id (owner/staff)
- DELETE /api/products/:id (owner/staff)
- POST /api/orders
- GET /api/orders     (owner/staff)
- PUT /api/orders/:id/deliver (owner/staff)
- GET /api/inventory/sales-summary (owner)
- POST /api/conversion (owner)
- GET /api/conversion  (owner/staff)
- GET /api/staff (owner)
- POST /api/staff (owner)

Deployment notes
----------------
- Use MongoDB Atlas for cloud DB.
- Deploy the backend to Render, Railway, Fly.io, or a VPS. Vercel can host serverless functions but for full API a dedicated backend is easier.
- Set environment variables on the host (MONGO_URI, JWT_SECRET).

Next steps I can do for you (tell me and I will implement):
- Integrate this backend with your frontend demo (update AJAX calls + auth flows).
- Add file/image uploads for product images (S3).
- Add payment integration (Razorpay).
- Create Dockerfile and Kubernetes manifest for production containers.

If you want, I can now:
A) Integrate this backend with the previously-generated static frontend (convert fetch/localStorage to real API calls, add login flow).
B) Prepare a full zip containing both frontend + backend and step-by-step deploy instructions to Render (API) + Vercel (frontend).

Tell me which of A/B you want and I'll produce the combined ZIP and exact deploy steps.


SAMPLE CREDENTIALS
- Owner: owner@yadukul.local / owner123 (created by seed script)

DEPLOYMENT SUGGESTION
- Use Render or Railway for hosting backend. Set MONGO_URI and JWT_SECRET in environment variables.
