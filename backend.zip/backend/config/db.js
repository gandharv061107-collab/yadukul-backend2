const mongoose = require('mongoose');
const url = process.env.MONGO_URI || 'mongodb://localhost:27017/yadukul';
module.exports = function connectDB(){
  mongoose.connect(url, {useNewUrlParser:true, useUnifiedTopology:true})
    .then(()=> console.log('MongoDB connected'))
    .catch(err=> { console.error('MongoDB connection error:', err.message); process.exit(1);})
}
