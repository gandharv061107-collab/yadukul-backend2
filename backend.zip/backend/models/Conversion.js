const mongoose = require('mongoose');
const ConversionSchema = new mongoose.Schema({
  date: {type:Date, default: Date.now},
  milk_received: Number,
  dahi_made: Number,
  other_products: [{name:String, qty:Number, unit:String}]
});
module.exports = mongoose.model('Conversion', ConversionSchema);
