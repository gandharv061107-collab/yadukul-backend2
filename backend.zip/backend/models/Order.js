const mongoose = require('mongoose');
const OrderSchema = new mongoose.Schema({
  customer: {
    name:String, phone:String, address:String
  },
  items: [{ productId:{type:mongoose.Schema.Types.ObjectId, ref:'Product'}, name:String, price:Number, qty:Number, type:String }],
  status: {type:String, enum:['pending','delivered'], default:'pending'},
  channel: {type:String, enum:['home','counter'], default:'home'},
  created_at:{type:Date, default:Date.now},
  updated_at:Date
});
module.exports = mongoose.model('Order', OrderSchema);
