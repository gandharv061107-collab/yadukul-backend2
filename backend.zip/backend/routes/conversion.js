const express = require('express');
const router = express.Router();
const Conversion = require('../models/Conversion');
const auth = require('../middleware/auth');

router.post('/', auth, async (req,res)=>{
  if(req.user.role!=='owner') return res.status(403).json({msg:'forbidden'});
  const doc = await Conversion.create(req.body);
  res.json(doc);
});
router.get('/', auth, async (req,res)=>{
  if(!['owner','staff'].includes(req.user.role)) return res.status(403).json({msg:'forbidden'});
  const docs = await Conversion.find().sort({date:-1});
  res.json(docs);
});
module.exports = router;
