const express = require('express');
const router = express.Router();
const Order = require('../models/Order');
const auth = require('../middleware/auth');

router.get('/sales-summary', auth, async (req,res)=>{
  if(req.user.role!=='owner') return res.status(403).json({msg:'forbidden'});
  const orders = await Order.find();
  const summary = {};
  orders.forEach(o=>{
    o.items.forEach(it=>{
      if(!summary[it.name]) summary[it.name]={qty:0,revenue:0};
      summary[it.name].qty += it.qty;
      summary[it.name].revenue += it.qty * it.price;
    });
  });
  res.json(summary);
});

module.exports = router;
