const express = require('express');
const router = express.Router();
const Order = require('../models/Order');
const Product = require('../models/Product');
const auth = require('../middleware/auth');

// create order (customer or owner)
router.post('/', async (req,res)=>{
  try{
    const {customer, items, channel} = req.body;
    if(!customer || !items || !items.length) return res.status(400).json({msg:'Invalid'});
    const order = await Order.create({customer, items, channel});
    res.json(order);
  }catch(e){ console.error(e); res.status(500).json({msg:'err'})}
});

// get orders (protected)
router.get('/', auth, async (req,res)=>{
  // owner and staff can see all, customer see own (if id matches)
  if(req.user.role==='customer'){ return res.status(403).json({msg:'use /my endpoint'})}
  const orders = await Order.find().sort({created_at:-1});
  res.json(orders);
});

router.get('/my', auth, async (req,res)=>{
  // for demo, no direct user->orders link. Provide by phone/email in query
  const q = req.query.phone;
  if(!q) return res.status(400).json({msg:'phone required'});
  const orders = await Order.find({'customer.phone': q});
  res.json(orders);
});

router.put('/:id/deliver', auth, async (req,res)=>{
  if(!['owner','staff'].includes(req.user.role)) return res.status(403).json({msg:'forbidden'});
  const order = await Order.findById(req.params.id);
  if(!order) return res.status(404).json({msg:'not found'});
  order.status='delivered'; order.updated_at = new Date();
  await order.save();
  // deduct stock
  for(const it of order.items){
    await Product.findByIdAndUpdate(it.productId, {$inc: {qty: -it.qty}});
  }
  res.json(order);
});

module.exports = router;
