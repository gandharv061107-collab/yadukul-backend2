const express = require('express');
const router = express.Router();
const Product = require('../models/Product');
const auth = require('../middleware/auth');

// Public get products
router.get('/', async (req,res)=>{ const p = await Product.find(); res.json(p) })

// Protected routes (owner/staff)
router.post('/', auth, async (req,res)=>{
  if(!['owner','staff'].includes(req.user.role)) return res.status(403).json({msg:'forbidden'});
  const data = req.body;
  const prod = await Product.create(data);
  res.json(prod);
});
router.put('/:id', auth, async (req,res)=>{
  if(!['owner','staff'].includes(req.user.role)) return res.status(403).json({msg:'forbidden'});
  const prod = await Product.findByIdAndUpdate(req.params.id, req.body, {new:true});
  res.json(prod);
});
router.delete('/:id', auth, async (req,res)=>{
  if(!['owner','staff'].includes(req.user.role)) return res.status(403).json({msg:'forbidden'});
  await Product.findByIdAndDelete(req.params.id);
  res.json({ok:true});
});

module.exports = router;
