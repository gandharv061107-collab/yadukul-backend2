const express = require('express');
const router = express.Router();
const User = require('../models/User');
const auth = require('../middleware/auth');

// list staff (owner)
router.get('/', auth, async (req,res)=>{
  if(req.user.role!=='owner') return res.status(403).json({msg:'forbidden'});
  const staff = await User.find({role:{$in:['staff']}}).select('-passwordHash');
  res.json(staff);
});

// add staff
router.post('/', auth, async (req,res)=>{
  if(req.user.role!=='owner') return res.status(403).json({msg:'forbidden'});
  const {name,email,phone,password,role} = req.body;
  if(!email||!password||!name) return res.status(400).json({msg:'missing'});
  const bcrypt = require('bcrypt');
  const hash = await bcrypt.hash(password,10);
  const u = await User.create({name,email,phone,role:role||'staff',passwordHash:hash});
  res.json({ok:true, id:u._id});
});

module.exports = router;
