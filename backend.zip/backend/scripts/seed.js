require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('../config/db');
const bcrypt = require('bcrypt');
const User = require('../models/User');
const Product = require('../models/Product');

const seed = async ()=>{
  await connectDB();
  await User.deleteMany({});
  await Product.deleteMany({});
  const pass = await bcrypt.hash('owner123', 10);
  const owner = await User.create({name:'Owner', email:'owner@yadukul.local', role:'owner', passwordHash:pass, phone:'9999999999'});
  console.log('Created owner:', owner.email, 'password: owner123');
  const p1 = await Product.create({name:'Cow Milk', price:40, unit:'litre', qty:500, img:'', type:'cow'});
  const p2 = await Product.create({name:'Buffalo Milk', price:50, unit:'litre', qty:300, img:'', type:'buffalo'});
  const p3 = await Product.create({name:'Dahi', price:60, unit:'kg', qty:100, img:'', type:'other'});
  console.log('Sample products created');
  process.exit(0);
};
seed();
